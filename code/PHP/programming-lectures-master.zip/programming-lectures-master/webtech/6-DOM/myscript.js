// read document.js mdn --> to learn about best resources.
//url: https://developer.mozilla.org/en-US/docs/Web/API/Document

//console.log(document);
console.log(document.head);
//console.log(document.title);
//alert(document.title);
//console.log(document.documentURI);
//console.log(document.location);