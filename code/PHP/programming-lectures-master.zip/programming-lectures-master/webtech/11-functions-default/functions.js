let greeting = function(){
    console.log("Hello guys, how are you?");
    }

let greeting1 = function(name){
    console.log("Hello "+name+" how are you?");
    
}
greeting();
greeting1("chetan");

let sum = function(num1, num2){
    return (num1+num2);
}
console.log(sum(2,3));