let loggedIn = false;

let username = "chetanhere";
let password = "password";

// real username = chetanhere;
// real password = password;

if(username == "chetanhere" && password == "password"){
    loggedIn = true;
}
else{
    loggedIn = false;
}

console.log(loggedIn);
