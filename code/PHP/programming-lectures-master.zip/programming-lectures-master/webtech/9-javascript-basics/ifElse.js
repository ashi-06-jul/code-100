// if else

let num = 2;
if(num == 1){
    console.log("you are in one");
    
}
else{
    console.log("You are at wrong place");
    
}
