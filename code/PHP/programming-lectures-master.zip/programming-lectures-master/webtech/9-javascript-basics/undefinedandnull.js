// Declare a variable

// null is an assigned value. It means nothing.
// undefined means a variable has been declared but not defined yet.
// null is an object. undefined is of type undefined.

let test1 = null;

console.log(test1);

// typeof

console.log(typeof(test1));


let test2;

console.log(test2);

console.log(typeof(test2));

let test3 = undefined;

console.log(test3);


console.log(typeof(test3));

let test4 = {};

console.log(test4.prop);

console.log(null==undefined);
console.log(null!==undefined);









