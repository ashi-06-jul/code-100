let names = ["chetan", "mayur", "gunjan", "shriyai"];

console.log(names[1]);
console.log(names[names.length-1]);

for(i =0; i<names.length; i++){
    console.log(names[i]);
    
}

