// define and initialize a variable

let score=0;
const bonus = 30;

//print value of score
console.log("your score is "+ score);


// update score
//let score = 110; // not allowed
bonus = -15;
score = 110;

//let bonus = -15;
 // equation
 // score = score X (1+ bonus/100)
score = score* (1+ bonus/100);

console.log("updated score "+ score);
