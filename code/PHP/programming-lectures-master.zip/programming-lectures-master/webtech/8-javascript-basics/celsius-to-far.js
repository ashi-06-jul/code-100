// put a variable to hold temp in celsius
let tempC = 27;


// take a variable to update the value in far
let tempF;


// apply mathematical logic
//equation tempF = tempC X 9/5 + 32
tempF = tempC * (9/5)+ 32;


// print the value to user
console.log(tempC + " C is eqaul to "+ tempF + " Farenhite");
