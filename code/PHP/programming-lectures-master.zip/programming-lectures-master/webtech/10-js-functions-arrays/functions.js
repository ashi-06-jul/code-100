let sum = function(num1, num2){
    res = num1 + num2;
    return res;
}
let intro = function(myage){
    console.log("my name is chetan");
    
}
intro(30);
console.log(sum(2,3));

let sayHello = function(name){
    console.log('hello ${name}');
    
}

sayHello("Mayur");
