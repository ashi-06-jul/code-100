<?php 
$name = "Chetan";
$age = 30;
echo "Hello $name, you are $age years old.<br>";
$N = 3;
$ageN = $age+$N;
echo "$name will be $ageN years old after $N years.";
/* nl2br() is used to line break*/

?>