<html>
   <body>
   
      <?php require("x-menu.php"); ?>
      <p>This is an example to show how to include PHP file!</p>
      
   </body>
</html>