<a href="http://kiet.edu">Home</a> - 
<a href="http://kiet.edu/BTECH">BTECH</a> - 
<a href="http://kiet.edu/MTECH">MTECH</a> - 
<a href="http://kiet.edu/MCA">MCA</a> <br />