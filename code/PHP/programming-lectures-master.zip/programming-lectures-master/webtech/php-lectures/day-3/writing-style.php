<?
echo "I am php<br>";
print "I am php 2";
?>