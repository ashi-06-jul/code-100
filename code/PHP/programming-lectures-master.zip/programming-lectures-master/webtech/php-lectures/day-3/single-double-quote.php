<?
$name = "chetan";
$single_quote = 'my name is $name';
$double_quote = "my name is $name";
print("$single_quote<br>");
print($double_quote);
?>