<?

echo __LINE__;
/* we also use __FILE__ __METHOD__ __CLASS__ __FUNCTION__ */

?>