<html>
<title>Hello PHP</title>
<body>
    <?php echo '<p>Hello PHP</p>'?>
</body>

</html>