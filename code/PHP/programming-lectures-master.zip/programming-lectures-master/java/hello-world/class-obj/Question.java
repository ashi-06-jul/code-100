public class Question{
    int var1, var2;
    int sum(int val1, int val2){
        int res = val1+val2;
        return res;
    }
}