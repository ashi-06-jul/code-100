public class QuizTest{
    public static void main(String[] args) {
        Question q1 = new Question();
        q1.var1 = 2;
        q1.var2 =3;
        System.out.println(q1.sum(2, 5));
    }
}