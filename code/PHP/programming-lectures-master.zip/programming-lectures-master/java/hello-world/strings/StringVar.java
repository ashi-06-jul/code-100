public class StringVar{
    public static void main(String[] args) {
        String firstName = "Chetan";
        String lastName = "Vashistth";
        System.out.println(firstName+ " " + lastName);

        // how  toLowerCase() and toUpperCase() works?

        System.out.println(firstName.toUpperCase());
        System.out.println(lastName.toLowerCase());

    }
    
}