public class VariableValue{
    public static void main(String[] args) {
        
        long power = 1000000;
        int time = 0;

        System.out.println("Power after time "+ time + " ms is "+power);
        // try to make a method for it and replace the line with method call

         time = 10;
         power = power - 100000;

         System.out.println("Power after time "+ time + " ms is "+power);

         time = 20;
         power = power - 100000;

         System.out.println("Power after time "+ time + " ms is "+power);

         // make a method to update and return the value of power after any given time

    
    }
    
}