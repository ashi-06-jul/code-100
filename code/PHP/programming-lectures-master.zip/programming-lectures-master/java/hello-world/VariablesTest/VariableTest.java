public class VariableTest{
    public static void main(String[] args) {
        
        System.out.println("Size of integer is :"+ Integer.SIZE+ " bits");
        System.out.println("Size of double is :"+ Double.SIZE+ " bits");
        System.out.println("Size of char is :"+ Character.SIZE+ " bits");
        System.out.println("Size of long is :"+ Long.SIZE+ " bits");
    }
    
}