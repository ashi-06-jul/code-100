# 100-days-ml-code
I would be coding Machine Learning at least 1 hour daily for next 100 days.

## Logs
[Daily logs](https://github.com/chetanhere/100-days-ml-code/blob/master/logs.md)
