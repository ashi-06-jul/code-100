# My Daily Logs of 100 Days ML Code Challenge

## Day 1:
### Today, I have brushed some of my python skills and also studied some introduction to Machine Learning algorithms.

## Day 2:
### Today, I have learnt about the basics of Haar Like features and theory behind face recognition.

## Day 25:
### Learnt about p-value, null hypothesis and alternate hypothesis. Also have learnt about Simple Linear Regression and multi valued Linear Regression.
