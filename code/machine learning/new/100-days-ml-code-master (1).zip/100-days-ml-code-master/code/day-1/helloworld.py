print("hello world, I am learning Python")
print(2+4)

num_1 = 5
num_2 =7

num_3 = num_1+num_2
print(num_3)
