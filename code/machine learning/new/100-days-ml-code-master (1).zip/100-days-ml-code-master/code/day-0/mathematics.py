from math import *

num = 10
num_2 = -5

print(abs(num_2))
print(pow(num, 2))

#max, min and round

print(max(2, 3, -10, -7, 0))
print(min(2, 3, -10, -7, 0))
print(round(3.5))
print(round(2.7))
print(round(2.3))

#other functions
# from math import *

print(sqrt(36))
print(floor(3.6))
print(ceil(3.6))