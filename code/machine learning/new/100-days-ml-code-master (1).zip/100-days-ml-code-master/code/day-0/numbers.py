print(2)
print(3.9)
print(-2.3)

# operations

print(2/3)
print(3*4+2)
print(3*(4+2))

print(10%3)

#print favorite number

my_fav = 10

#print(my_fav+" is my favorite number")

print(str(my_fav)+" is my favorite number")
