name = input("Enter your name:__________")
print("Hello "+name+"! hope, you are enjoying")