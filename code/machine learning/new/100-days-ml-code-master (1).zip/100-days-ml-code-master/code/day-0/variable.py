name = "Chetan Vashistth"
firstName = "chetan"
lastName = "Vashistth"
print(name)
print(firstName+" python "+lastName)

#  how to trace index
print(name.index("C"))

# Using replace function
print(name.replace("Chetan", "Mayur"))