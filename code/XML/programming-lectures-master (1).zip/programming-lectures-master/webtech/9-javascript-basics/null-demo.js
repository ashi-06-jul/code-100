let firstName = null;

let lastName;

console.log(firstName);
let number1 = 123;
console.log(typeof(number1));

// response : null 

// typeof function is used to return the type of any data.

console.log(typeof(firstName));
// response : object
console.log(lastName);
// undefined
console.log(typeof(lastName));
// undefined

console.log(undefined == null);

// true

console.log(undefined !== null);

// true

let numArray = {};
console.log(numArray.prop);

