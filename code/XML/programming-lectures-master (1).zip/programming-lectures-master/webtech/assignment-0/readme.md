[Link for this hosted tutorial](https://codepathshala.github.io/projects/kiet-mca-2018/student-profiles/)
