//document.title = 'something else';
//console.log(document.getElementById('paraone'));
//console.log(document.getElementsByClassName('classone'));

//const myelement = document.querySelector('p');
//console.log(myelement);

const myelement = document.querySelectorAll('p');
//console.log(myelement);
//console.log(myelement[2]);
myelement[2].textContent = "Hurray, we are the world";

