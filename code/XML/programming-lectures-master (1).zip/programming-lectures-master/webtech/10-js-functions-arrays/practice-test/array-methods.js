// Create and initialize an Array
let numbers = [1, 2, 3, 4, 5];


// shift one element
console.log(numbers.shift());

// print remaining array
console.log(numbers);


// unshift a number
console.log(numbers.unshift(6));



//print array
console.log(numbers);



// pop an element from array


//print array


// push an element

// print element

// use splice to change value at a specific position

// print the array








