let family =["chetan", "mayur", "gunjan", "shriyai", "bhawana"];
console.log(family);
console.log(family.shift());
console.log(family);
console.log(family.unshift("Chetan Vashistth"));
console.log(family);


// above is to change things at start of array

console.log(family.pop());
console.log(family);

console.log(family.push("Bhawana"));
console.log(family);

//above is to change things at end of array


console.log(family.splice(1, 2, "Family One", "family two"));
console.log(family);








